package com.ssafy.di4_의존성주입;

public class Desktop implements Computer {
	// 필드명 작성
	// CPU, GPU, RAM, ... 등등
	
	// 정보를 반환
	public String getInfo() {
		return "데스크톱";
	}
}
