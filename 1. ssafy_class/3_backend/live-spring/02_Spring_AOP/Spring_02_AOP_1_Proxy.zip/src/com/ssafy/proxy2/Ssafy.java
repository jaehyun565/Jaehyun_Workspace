package com.ssafy.proxy2;

public class Ssafy implements Person {
	// 필드는 과감히 생략!

	// 교육생의 일상
	public void coding() {
		System.out.println("열심히 공부를 한다."); // 핵심관심사항
	}

}
