package com.ssafy.myservlet;

import jakarta.servlet.http.HttpServlet;

public class MyServlet3 extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	//doXXXX 은 적어도 1개는 만들어어야 해
}
