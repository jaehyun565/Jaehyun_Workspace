<template>
  <ul>
    <CartItem
      v-for="cartItem in cart" 
      :key="cartItem.id" 
      :product="cartItem"

      @remove-item="removeItem"
    />
  </ul>
</template>

<script setup>
import CartItem from '@/components/CartItem.vue'

defineProps({
  cart: Array
});

const emit = defineEmits([
  'removeItem'
]);

const removeItem = (product) => {
  emit('removeItem', product);
}
</script>
