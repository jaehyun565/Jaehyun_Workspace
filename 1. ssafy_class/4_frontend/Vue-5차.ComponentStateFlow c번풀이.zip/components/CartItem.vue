<template>
  <li>
    {{ product.name }} - {{ product.price }}원
    <button @click="removeItem(product)">삭제</button>
  </li>
</template>

<script setup>
defineProps({
  product: Object
})

const emit = defineEmits([
  'removeItem'
]);

const removeItem = (product) => {
  emit('removeItem', product);
}
</script>

<style scoped>

</style>
