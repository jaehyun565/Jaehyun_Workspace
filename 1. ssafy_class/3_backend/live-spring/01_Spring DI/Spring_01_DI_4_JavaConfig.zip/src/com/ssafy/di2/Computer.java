package com.ssafy.di2;

public interface Computer {
	String getInfo();
}
