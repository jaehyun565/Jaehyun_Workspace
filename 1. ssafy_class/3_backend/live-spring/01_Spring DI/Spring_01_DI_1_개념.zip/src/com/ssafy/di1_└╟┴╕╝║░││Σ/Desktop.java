package com.ssafy.di1_의존성개념;

public class Desktop {
	// 필드명 작성
	// CPU, GPU, RAM, ... 등등
	
	// 정보를 반환
	public String getInfo() {
		return "데스크톱";
	}
}
