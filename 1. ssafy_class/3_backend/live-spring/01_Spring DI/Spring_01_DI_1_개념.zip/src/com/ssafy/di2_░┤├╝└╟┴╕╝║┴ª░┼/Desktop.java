package com.ssafy.di2_객체의존성제거;

public class Desktop {
	// 필드명 작성
	// CPU, GPU, RAM, ... 등등
	
	// 정보를 반환
	public String getInfo() {
		return "데스크톱";
	}
}
