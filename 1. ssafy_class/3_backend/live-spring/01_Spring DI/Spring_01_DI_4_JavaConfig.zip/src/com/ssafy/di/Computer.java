package com.ssafy.di;

public interface Computer {
	String getInfo();
}
