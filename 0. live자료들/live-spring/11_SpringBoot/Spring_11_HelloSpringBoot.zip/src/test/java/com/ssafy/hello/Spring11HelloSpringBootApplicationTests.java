package com.ssafy.hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring11HelloSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
