<template>
  <div>
    <h1>쇼핑 애플리케이션</h1>
    <h2>상품 목록</h2>
    <ProductList :products="products" @add-to-cart="addToCart"/>
    <h2>장바구니 목록</h2>
    <p> 총 금액 : {{ totalPrice }}</p>
    <Cart :cart="cart" @remove-item="removeItem" />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import ProductList from '@/components/ProductList.vue'
import Cart from '@/components/Cart.vue'

const products = ref([
  { id: 1, name: '사과', price: 1000 },
  { id: 2, name: '바나나', price: 1500 },
  { id: 3, name: '딸기', price: 2000 },
  { id: 4, name: '포도', price: 3000 },
  { id: 5, name: '복숭아', price: 2000 },
  { id: 6, name: '수박', price: 5000 }
]);

const cart = ref([
]);

const addToCart = (product)=>{
  const productArray = [];

  products.value.forEach((item) => {
    if (item.id === product.id) {
      cart.value.push(item);
    } else {
      productArray.push(item);
    }
  });

  products.value = productArray;
};

const removeItem = (product) => {
  const cartArray = [];
  cart.value.forEach((item) => {
    if (item.id === product.id) {
      products.value.push(item);
    } else {
      cartArray.push(item);
    }
  });
  cart.value = cartArray;
}

const totalPrice = computed(() => {
  let price = 0;
  cart.value.forEach((item) => {
    price += item.price;
  });
  return price;
});

</script>
